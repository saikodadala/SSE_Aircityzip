
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String


def static "actionLibrary.SeleniumActions.clickElement"(
    	TestObject to	) {
    (new actionLibrary.SeleniumActions()).clickElement(
        	to)
}

def static "actionLibrary.SeleniumActions.refreshBrowser"() {
    (new actionLibrary.SeleniumActions()).refreshBrowser()
}

def static "actionLibrary.SeleniumActions.getHtmlTableRows"(
    	TestObject table	
     , 	String outerTagName	) {
    (new actionLibrary.SeleniumActions()).getHtmlTableRows(
        	table
         , 	outerTagName)
}

def static "actionLibrary.SeleniumActions.isAlertPresent"() {
    (new actionLibrary.SeleniumActions()).isAlertPresent()
}

def static "actionLibrary.SeleniumActions.dynamic_Alert"() {
    (new actionLibrary.SeleniumActions()).dynamic_Alert()
}

def static "browser.SignIn.As"(
    	String User	
     , 	String password	) {
    (new browser.SignIn()).As(
        	User
         , 	password)
}

def static "browser.HighlightElement.run"(
    	TestObject objectto	) {
    (new browser.HighlightElement()).run(
        	objectto)
}

def static "browser.HighlightElement.validateTabledata"(
    	String headerName	
     , 	String expectedValue	) {
    (new browser.HighlightElement()).validateTabledata(
        	headerName
         , 	expectedValue)
}

def static "dataOperations.WriteToExcel.writeToExcel"(
    	String excelFileName	
     , 	String sheetName	
     , 	int iRow	
     , 	int iCell	
     , 	String iText	) {
    (new dataOperations.WriteToExcel()).writeToExcel(
        	excelFileName
         , 	sheetName
         , 	iRow
         , 	iCell
         , 	iText)
}
