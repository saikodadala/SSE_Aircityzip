<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>menu name</description>
   <name>OurPlans</name>
   <tag></tag>
   <elementGuidId>744a6cfa-2db4-42d2-a18e-416e39cefad2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[text()=${menuName}]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[text()=${menuName}]</value>
   </webElementProperties>
</WebElementEntity>
