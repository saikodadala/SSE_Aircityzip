<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>findmore option</description>
   <name>FindMore</name>
   <tag></tag>
   <elementGuidId>e08c1f40-2a2a-4f67-871d-3430fc3e98e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>[class='overlay ']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Facebook</value>
   </webElementProperties>
</WebElementEntity>
