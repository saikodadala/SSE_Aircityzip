<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_New customer plans</name>
   <tag></tag>
   <elementGuidId>ba7635b4-fcd2-4099-a3ef-5db27594c925</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/ie/home/products/switch-to-sse-airtricity/</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New customer plans</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;has-js has-cookies has-svg has-rgba has-srcset has-supports has-cssvhunit has-cssanimations has-csstransforms3d&quot;]/body[@class=&quot;page-dynamicbuilder&quot;]/div[@class=&quot;page-wrap&quot;]/div[@class=&quot;m-header  m-homepage-header&quot;]/div[@class=&quot;header-container&quot;]/div[@class=&quot;content&quot;]/ul[@class=&quot;navigation&quot;]/li[@class=&quot;nav-with-sub-menu nav-toplevel&quot;]/ul[1]/li[1]/a[1]</value>
   </webElementProperties>
</WebElementEntity>
