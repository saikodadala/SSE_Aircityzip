<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Book now</name>
   <tag></tag>
   <elementGuidId>d17c5cfe-de1d-43e5-adc7-beb04dcfda9e</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>c-button btn-cta -green</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.sseairtricity.com/ie/home/home-services/gas-boiler-service-and-climote/</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Book now</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;has-js has-cookies has-svg has-rgba has-srcset has-supports has-cssvhunit has-cssanimations has-csstransforms3d&quot;]/body[1]/div[@class=&quot;page-wrap&quot;]/div[@class=&quot;m-hero  -gradient -short -subtitle-small -light-dodger-blue&quot;]/div[@class=&quot;content-wrap&quot;]/a[@class=&quot;c-button btn-cta -green&quot;]</value>
   </webElementProperties>
</WebElementEntity>
