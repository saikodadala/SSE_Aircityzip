<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_At home</name>
   <tag></tag>
   <elementGuidId>3ba47f7c-cfb5-4d59-a04b-84ac61c593ba</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/ie/home</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>selected</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>At home</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;has-js has-cookies has-svg has-rgba has-srcset has-supports has-cssvhunit has-cssanimations has-csstransforms3d&quot;]/body[@class=&quot;page-dynamicbuilder&quot;]/div[@class=&quot;page-wrap&quot;]/div[@class=&quot;m-header  m-homepage-header&quot;]/div[@class=&quot;header-container&quot;]/div[@class=&quot;header&quot;]/ul[@class=&quot;change-user-type&quot;]/li[1]/a[@class=&quot;selected&quot;]</value>
   </webElementProperties>
</WebElementEntity>
