<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_We are SSE Airtricity</name>
   <tag></tag>
   <elementGuidId>3e23c9ac-e6fa-4400-98fc-327a8713b6a1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            We are SSE Airtricity
        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;has-js has-cookies has-svg has-rgba has-srcset has-supports has-cssvhunit has-cssanimations has-csstransforms3d&quot;]/body[@class=&quot;dom-com-theme&quot;]/div[@class=&quot;page-wrap&quot;]/div[@class=&quot;m-hero -long -gradient&quot;]/div[@class=&quot;content-wrap&quot;]/h2[@class=&quot;title&quot;]</value>
   </webElementProperties>
</WebElementEntity>
