package dataOperations

import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.kms.katalon.core.annotation.Keyword



public class WriteToExcel {

	@Keyword
	def void writeToExcel(String excelFileName, String sheetName,int iRow, int iCell, String iText ){

		String fileName=excelFileName
		fileName=System.getProperty("user.dir")+"\\Data Files\\"+fileName+'.xlsx'
		System.err.println(fileName)

		FileInputStream file = new FileInputStream (new File(fileName))
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet(sheetName)
		//Write data to excel'
		Row oRow;
		oRow = sheet.getRow(iRow-1);
		if(oRow == null){
			sheet.createRow(iRow-1);
			oRow = sheet.getRow(iRow-1);
		}
		Cell oCell;
		oCell = oRow.getCell(iCell - 1);
		if(oCell == null ){
			oRow.createCell(iCell - 1);
			oCell = oRow.getCell(iCell - 1);
		}
		oCell.setCellValue(iText);
		FileOutputStream outFile =new FileOutputStream(new File(fileName));
		workbook.write(outFile);
		outFile.close();
	}
}
