package browser
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

public class SignIn {

	public String testApp = GlobalVariable.testApp;
	public static String URL = "";
	//System.err.println(testApp);

	@Keyword
	public void As(String User, String password) throws Throwable {
		// -------------------------------- SIT SITE-------------------------------------------//

		if (testApp.replace(" ", "").toLowerCase().equals("sit"))
		{
			URL = "";
			System.err.println("-----LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(30)
			WebUI.setText(findTestObject('locator'), User)
			WebUI.setText(findTestObject('locator'), password)
			WebUI.click(findTestObject('signinButton'))
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)
			HomePageCondition()

		}

		// -------------------------------- WebApp SITE-------------------------------------------//

		else if (testApp.replace(" ", "").toLowerCase().equals("webapp"))
		{
			URL = "";
			System.err.println("-----LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(30)
			WebUI.setText(findTestObject('locator'), User)
			WebUI.setText(findTestObject('locator'), password)
			WebUI.click(findTestObject('signinButton'))
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- AGILE SITE-------------------------------------------//

		else if (testApp.replace(" ", "").toLowerCase().equals("agile"))
		{
			URL = "";
			System.err.println("-----LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(30)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Username'), User)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Password'), 'q')
			WebUI.click(findTestObject('Login_SIT_AGILE/Login_SignIn_Button'))
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- DEMO SITE-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("demo"))
		{
			URL = "https://logistics%5c" + User + ":" + password + "@"+GlobalVariable.DEMO+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}


		// -------------------------------- DEMO  173-------------------------------------------//

		else if (testApp.replace(" ", "").toLowerCase().equals("demo173"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.DEMO173+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- DEMO  174-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("demo174"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.DEMO174+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  45-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live45"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE45+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  46-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live46"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE46+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  181-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live181"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE181+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  182-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live182"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE182+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE SITE-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live"))
		{

			URL = "https://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()
		}


		else {

			System.err.println("NAZ LOG: FOCiS TEST APP DECLARED IN INCORRECT");
		}

	}

	public void HomePageCondition()
	{
		if (WebUI.waitForElementPresent(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), 3))
		{
			System.err.println("Quote List Home Page");
		}
		else
		{
			System.err.println("Banner Home Page");

			'Click to Quotation Tab'
			WebUI.click(findTestObject('Quotation/Menu/Quotation'))

			'Click to Manage Quotation Tab'
			WebUI.click(findTestObject('Quotation/Menu/Manage_Quotation'))

			'Wait until page is loaded'
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			'Take Screenshot of \'Quotation List Page\' '
			WebUI.takeScreenshot()
		}
	}

}



