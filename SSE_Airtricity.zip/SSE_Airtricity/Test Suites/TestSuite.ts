<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2019-04-27T08:11:18</lastRun>
   <mailRecipient>sai.k797@gmail.com;</mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>962b6d7b-65e5-498e-81b8-07e352ccde7a</testSuiteGuid>
   <testCaseLink>
      <guid>7ef58756-2bf3-4fc0-a206-e1f32af7536d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/GenericTestCaseForDemo</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
